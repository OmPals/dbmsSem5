INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
1, 'Paxon Oakhill', 'M', '3/3/2013', 
9005701692, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
2, 'Aube Spurdle', 'M', '8/4/1934', 
6718218405, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
3, 'Livy Oran', 'F', '7/11/2016', 0565576429, 
'58750-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
4, 'Jedidiah Benettelli', 'M', '10/16/1949', 
7943324323, '999-7767'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
5, 'Shirley McKague', 'F', '1/17/1974', 
8680474568, '77-124'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
6, 'Cammy Hardwick', 'F', '12/23/1960', 
3523245532, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
7, 'Jerry Klimushev', 'M', '9/9/1955', 
4810917185, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
8, 'Berty Debrick', 'M', '7/21/1983', 
5270139235, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
9, 'Roscoe Capeling', 'M', '7/9/1921', 
4187409017, '7340-214'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
10, 'Nissa Allewell', 'F', '7/11/1912', 
8512764910, 45750
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
11, 'Kippie Bamling', 'M', '3/3/1906', 
6170866179, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
12, 'Hendrick Plumb', 'M', '5/9/1948', 
0715903306, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
13, 'Ninetta Felgate', 'F', '11/2/1909', 
8511253262, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
14, 'Bar Bonas', 'M', '7/19/1914', 
4395050859, '62-570'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
15, 'Jeanelle Catherine', 'F', '12/26/1905', 
9136437956, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
16, 'Lorie Dresse', 'F', '8/25/1931', 
9291384887, '67144 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
17, 'Eziechiele Streeting', 'M', '11/21/1993', 
3240597748, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
18, 'Cyndy Gorioli', 'F', '5/11/1927', 
3232898637, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
19, 'Dun Upchurch', 'M', '8/10/1992', 
8256309784, 1485
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
20, 'Courtney Hedon', 'M', '7/27/1939', 
5909076027, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
21, 'Benedetta Tussaine', 'F', '1/31/1921', 
7516004979, '869-0233'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
22, 'Chet Tewkesberrie', 'M', '3/1/1936', 
0269314954, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
23, 'Daisi Habble', 'F', '7/9/1987', 
3651131629, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
24, 'Ayn Whoston', 'F', '11/2/1911', 
6008741560, '86000-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
25, 'Lia Davidsen', 'F', '12/19/2012', 
5032048259, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
26, 'Melisse Dilston', 'F', '1/4/1980', 
7392031147, 422840
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
27, 'Korrie Faulkner', 'F', '10/30/1951', 
8420670111, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
28, 'Khalil Snelling', 'M', '5/28/1981', 
8726804964, 690922
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
29, 'Gorden Itzchaki', 'M', '2/1/1988', 
3966282356, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
30, 'Anett Radbourn', 'F', '12/5/1975', 
0191282049, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
31, 'Winifield Jobling', 'M', '12/27/1987', 
3984127839, '533 52'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
32, 'John Vescovo', 'M', '5/23/1972', 
8566227697, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
33, 'Marshall Secrett', 'M', '1/14/1998', 
8976154541, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
34, 'Rancell Hawkridge', 'M', '5/9/2009', 
5897634955, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
35, 'Martin Speers', 'M', '6/9/1935', 
1761840606, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
36, 'Ricard Obray', 'M', '11/8/1970', 
9887870382, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
37, 'Darbee Meeson', 'M', '3/16/1942', 
7027218038, '78-524'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
38, 'Anissa McLugaish', 'F', '7/17/1908', 
6181416781, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
39, 'Del Scurrer', 'M', '11/1/2002', 
4218171890, '43-229'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
40, 'Sibyl Skaif', 'M', '10/3/1917', 
7546079268, 'L-9765'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
41, 'Liliane Follitt', 'F', '7/13/1909', 
7686002020, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
42, 'Frederique Dyers', 'F', '6/25/1909', 
4935115866, '796 25'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
43, 'Bryant Heinel', 'M', '1/30/1983', 
2134200871, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
44, 
'Redd O' Sherin ',' M ',' 8 / 22 / 2009 ',4599689734,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 45,' Mabel Otson ',' F ',' 4 / 30 / 1978 ',2338726987,' 29330 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 46,' Gino Chatin ',' M ',' 3 / 23 / 1994 ',5006315423,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 47,' Amanda Thornton ',' F ',' 12 / 15 / 1926 ',1904618847,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 48,' Elyssa Cogley ',' F ',' 10 / 31 / 1943 ',8389940299,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 49,' Vale Abramovitz ',' M ',' 7 / 19 / 1901 ',7690491189,86403);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 50,' Olivette Hemphill ',' F ',' 7 / 11 / 1987 ',7061501553,' P3L ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 51,' Dodie Kubacek ',' F ',' 9 / 1 / 1998 ',7869120103,250247);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 52,' Simona McIlmurray ',' F ',' 4 / 12 / 1967 ',0017954738,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 53,' Willem Sprull ',' M ',' 6 / 24 / 1971 ',7539806575,' L5W ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 54,' Roger Tootal ',' M ',' 8 / 11 / 1901 ',7718317552,303642);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 55,' Sashenka Iddiens ',' F ',' 5 / 30 / 2017 ',4596721076,' 811 - 2405 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 56,' Consolata Wadhams ',' F ',' 6 / 1 / 1923 ',3742185381,188420);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 57,' Hubert Talton ',' M ',' 10 / 8 / 1906 ',7553087351,' N37 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 58,' Adelbert Keyho ',' M ',' 8 / 24 / 1977 ',5857900670,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 59,' Andrej Bartles ',' M ',' 2 / 11 / 1936 ',0382114833,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 60,' Sibeal McIlraith ',' F ',' 3 / 1 / 1975 ',2689193574,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 61,' Christiano Minet ',' M ',' 11 / 24 / 1965 ',9968291277,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 62,' Xena Dureden ',' F ',' 7 / 10 / 1983 ',3712673639,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 63,' Jameson Liquorish ',' M ',' 2 / 11 / 1922 ',3018278224,' 465 96 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 64,' Edmon Filppetti ',' M ',' 1 / 3 / 1920 ',9480601168,' 503 - 2429 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 65,' Ellie Macauley ',' F ',' 11 / 23 / 1969 ',5235215729,243240);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 66,' Florencia Dusting ',' F ',' 12 / 19 / 2001 ',9454765094,' 4525 - 355 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 67,' Druci Colquitt ',' F ',' 8 / 28 / 2008 ',9054546484,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 68,' Clari Dilnot ',' F ',' 10 / 1 / 1929 ',1642738921,46852);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 69,' Luce MacKey ',' F ',' 8 / 28 / 1937 ',2882048823,04002);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 70,' Niccolo Bullingham ',' M ',' 12 / 8 / 2014 ',6914554056,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 71,' Giulia McGuckin ',' F ',' 12 / 2 / 1998 ',7517507796,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 72,' Julienne Mabbutt ',' F ',' 10 / 15 / 1961 ',3535912881,' 963 - 7856 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 73,' Pier Brake ',' F ',' 9 / 19 / 2018 ',7182987872,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 74,' Orv Mourton ',' M ',' 8 / 30 / 1935 ',0266320325,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 75,' Adam Iban ',' M ',' 11 / 15 / 1931 ',3547591694,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 76,' Elden Shyre ',' M ',' 1 / 21 / 1901 ',1735369195,10508);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 77,' Catarina Kall ',' F ',' 10 / 4 / 1950 ',5633470478,' 28890 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 78,' Brenda Rodders ',' F ',' 4 / 6 / 1950 ',5944900229,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 79,' Billie Orkney ',' F ',' 8 / 7 / 1915 ',1006233288,3122);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 80,' Harriett Yakov ',' F ',' 3 / 21 / 1934 ',2470070627,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 81,' Dayna Dunbleton ',' F ',' 7 / 10 / 1987 ',0615813801,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 82,' Adria Korting ',' F ',' 7 / 5 / 1904 ',4619029149,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 83,' Zak Burney ',' M ',' 6 / 28 / 1933 ',9623730543,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 84,' Audry Firmager ',' F ',' 5 / 11 / 1901 ',4021053417,2156);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 85,' Shelia Mahoney ',' F ',' 8 / 27 / 1943 ',3409812814,' 98 - 311 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 86,' Mirelle Winship ',' F ',' 8 / 25 / 1938 ',9945278665,188355);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 87,' Carmon Trimble ',' F ',' 12 / 15 / 1991 ',0693006285,72905);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 88,' Jasmin Cockayne ',' F ',' 7 / 18 / 1958 ',5044678813,25590);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 89,' Gregorius Templeton ',' M ',' 1 / 7 / 1914 ',7067527716,354084);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 90,' Abram Collyear ',' M ',' 1 / 11 / 2013 ',2702214010,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 91,' Ellie Thorald ',' F ',' 11 / 18 / 1926 ',4098309122,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 92,' Carolynn Szimon ',' F ',' 5 / 28 / 1971 ',8823643503,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 93,' Claire Early ',' F ',' 11 / 9 / 1932 ',0612003701,172029);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 94,' Connie Oscroft ',' M ',' 9 / 14 / 1944 ',0063533715,' 74 - 202 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 95,' Lind Knewstubb ',' F ',' 7 / 13 / 1900 ',6889612655,054028);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 96,' Glynda Bettridge ',' F ',' 7 / 24 / 2005 ',6571136945,' 72 - 210 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 97,' Karoly Bircher ',' M ',' 6 / 7 / 1989 ',9255028685,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 98,' Vick Petrus ',' M ',' 12 / 9 / 1959 ',7313207743,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 99,' Rancell Orth ',' M ',' 4 / 10 / 1906 ',9068466100,682803);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 100,' Alfred Sprackling ',' M ',' 8 / 20 / 1963 ',6555313145,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 101,' Fionna Chartres ',' F ',' 9 / 28 / 2001 ',6075793844,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 102,' Eugene Simson ',' M ',' 2 / 26 / 1964 ',5616667501,' 35903 CEDEX 9 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 103,' Datha Bradlaugh ',' F ',' 12 / 22 / 1956 ',2054951544,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 104,' Lennard Bonnin ',' M ',' 2 / 12 / 1937 ',0671363107,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 105,' Merle Loseke ',' M ',' 4 / 2 / 1957 ',1587033445,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 106,' Dyana Elliot ',' F ',' 7 / 26 / 1914 ',4018939604,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 107,' Herc Bonett ',' M ',' 12 / 14 / 1946 ',6435155283,142717);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 108,' Ulrick Tolputt ',' M ',' 7 / 4 / 1903 ',7726277467,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 109,' Roseanna MacWhan ',' F ',' 3 / 21 / 2016 ',6598745241,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 110,' Tammy Gerretsen ',' M ',' 11 / 3 / 1928 ',3701321078,2421);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 111,' Fritz McKissack ',' M ',' 4 / 26 / 1949 ',7586695954,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 112,' Manolo Caddie ',' M ',' 4 / 21 / 1908 ',5687456309,357371);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 113,' Fitzgerald Sanpher ',' M ',' 5 / 24 / 2015 ',8934480157,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 114,' Morgan Scrine ',' F ',' 9 / 10 / 1943 ',8861399088,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 115,' Olivier Henrion ',' M ',' 5 / 25 / 1996 ',3771181089,' 74304 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 116,' Milicent Shead ',' F ',' 7 / 27 / 1906 ',4331022609,44710);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 117,' Marchall Pechan ',' M ',' 6 / 16 / 1963 ',9191738512,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 118,' Wes Maylour ',' M ',' 10 / 3 / 1983 ',5533615997,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 119,' Ibby Lawes ',' F ',' 6 / 9 / 1927 ',1845102312,79710);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 120,' Barbara - anne Almak ',' F ',' 9 / 19 / 1936 ',7022061017,' 522 32 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 121,' Josiah Van Bruggen ',' M ',' 6 / 15 / 1907 ',5198884022,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 122,' Gillian Penn ',' F ',' 9 / 7 / 1935 ',6150129802,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 123,' Radcliffe Goater ',' M ',' 8 / 26 / 2009 ',9666863162,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 124,' Rahel Boness ',' F ',' 9 / 25 / 1956 ',7117364726,' 3250 - 104 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 125,' Herold Worster ',' M ',' 4 / 15 / 1981 ',1961408856,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 126,' Taddeusz Jiggle ',' M ',' 6 / 28 / 1957 ',2283546176,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 127,' Antonin Chatres ',' M ',' 11 / 10 / 2000 ',9675795409,646604);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 128,' Ranique Heakins ',' F ',' 2 / 6 / 1988 ',8993006792,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 129,' Godfrey Whimper ',' M ',' 12 / 7 / 2011 ',2287781536,399612);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 130,' Izaak Canet ',' M ',' 2 / 28 / 1909 ',7379632175,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 131,' Estrellita McKeever ',' F ',' 1 / 19 / 1918 ',2534616390,2516);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 132,' Patrizia Tindall ',' F ',' 7 / 25 / 1905 ',4068017484,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 133,' Jodie Cater ',' M ',' 1 / 9 / 1966 ',2157121404,' N37 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 134,' Pren O 'Codihie', 
'M', 
'6/19/1976', 
2874146331, 
''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
135, 'Frederico Smardon', 'M', '8/6/1955', 
8650568424, '4610-572'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
136, 'Dotti Giddons', 'F', '10/11/1908', 
8386415290, 5504
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
137, 'Kean Mickleburgh', 'M', '5/30/1954', 
6259734611, 4839
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
138, 'Clark Kellen', 'M', '2/14/1963', 
1838166750, 5041
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
139, 'Tabitha Tuminini', 'F', '2/13/2003', 
2864485842, 9105
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
140, 'Doretta Niess', 'F', '3/2/1900', 
0099344513, 8336
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
141, 'Selinda Honacker', 'F', '11/2/1933', 
7978792773, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
142, 'Orin Duran', 'M', '1/16/1935', 
0613656571, '33010 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
143, 'Novelia Townley', 'F', '7/23/1998', 
2150457407, '32-125'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
144, 'Cliff Tolhurst', 'M', '6/5/1903', 
5137486094, '504-0968'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
145, 'Baily Haining', 'M', '11/12/1901', 
3937610472, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
146, 'Aurelia Vanderson', 'F', '8/13/1935', 
2878302176, 682738
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
147, 'Calley Lofting', 'F', '8/25/1948', 
4318785327, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
148, 'Norah Lethbridge', 'F', '10/18/2014', 
5394071268, 34201
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
149, 'Carlita Merill', 'F', '2/22/1966', 
2102209830, 4200
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
150, 'Ettore Eckford', 'M', '7/8/1903', 
5926785715, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
151, 'Cecil Kuban', 'M', '5/9/1904', 
4251741536, 5196
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
152, 'Donnamarie Snawdon', 'F', '3/27/1947', 
3737296278, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
153, 'Kayne Dinjes', 'M', '11/4/1942', 
1147311234, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
154, 'Merla Nicol', 'F', '9/26/2006', 
9996934985, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
155, 'Edwin Ulyat', 'M', '11/16/1982', 
3303231567, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
156, 'Elnar Ettles', 'M', '1/11/1917', 
6153001378, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
157, 'Alexia Burnand', 'F', '5/5/1957', 
1259743896, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
158, 'Sarge Swate', 'M', '2/3/1998', 
5937872169, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
159, 'Mella Rennels', 'F', '6/26/1960', 
7316152982, 38796
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
160, 'Halsey Readwin', 'M', '2/21/1919', 
3931068013, 652380
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
161, 'Jere Andreacci', 'M', '1/18/2006', 
6151013948, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
162, 'Rena Crollman', 'F', '7/1/1966', 
5999668646, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
163, 'Tim Abramof', 'M', '8/1/1935', 
8541865592, 70150
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
164, 'Dolli Camp', 'F', '3/7/1997', 
3795483832, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
165, 'Kris Wholesworth', 'M', '3/6/1972', 
2135124648, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
166, 
'Danila O' Kennedy ',' F ',' 7 / 5 / 1938 ',5359088052,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 167,' Alwin Cockshtt ',' M ',' 6 / 20 / 1909 ',7284353236,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 168,' Colas Marmion ',' M ',' 6 / 4 / 1919 ',8918330227,' 63 - 460 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 169,' Carlita Konzel ',' F ',' 12 / 7 / 1971 ',4572665141,' 45650 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 170,' Casey Compton ',' M ',' 5 / 11 / 1909 ',8656928996,27944);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 171,' Evangeline Mandeville ',' F ',' 9 / 2 / 1921 ',5157561113,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 172,' Tiffy Moggan ',' F ',' 5 / 21 / 1928 ',1222986426,7402);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 173,' Levey Guitton ',' M ',' 8 / 19 / 1951 ',4713900621,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 174,' Solomon Barhem ',' M ',' 2 / 9 / 2003 ',7954561097,4021);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 175,' Gusti Pearn ',' F ',' 11 / 8 / 1949 ',9306430345,' MGR ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 176,' Yoshi Tasker ',' F ',' 1 / 26 / 1903 ',4980603637,' 06 - 121 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 177,' Gustie Purser ',' F ',' 5 / 14 / 1997 ',3081755212,' 745 44 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 178,' Lacie Ruckhard ',' F ',' 4 / 7 / 1921 ',7197158788,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 179,' Bing Have ',' M ',' 12 / 23 / 1949 ',3518532227,' 83404 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 180,' Lindsay McGuiness ',' M ',' 3 / 10 / 1928 ',8763224380,' 32 - 002 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 181,' Fernando McCaffrey ',' M ',' 7 / 14 / 1999 ',2452683841,6342);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 182,' Alison Crofts ',' F ',' 11 / 26 / 2013 ',4071739800,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 183,' Ansell Fretson ',' M ',' 6 / 6 / 2013 ',4811129679,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 184,' Mozes Vasyunin ',' M ',' 12 / 25 / 2008 ',8174761489,46025);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 185,' Shanda Pottinger ',' F ',' 12 / 7 / 2008 ',2684070733,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 186,' Billie Battey ',' F ',' 7 / 7 / 1908 ',9240386599,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 187,' Sandye Reignolds ',' F ',' 5 / 6 / 1984 ',8584929207,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 188,' Frederick De Wolfe ',' M ',' 2 / 21 / 1920 ',2970740893,' 08 - 440 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 189,' Dominique Brussell ',' M ',' 6 / 10 / 2015 ',5723305255,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 190,' Austin Clorley ',' F ',' 9 / 28 / 2002 ',1883041902,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 191,' Valaree Burditt ',' F ',' 3 / 8 / 1978 ',5459636493,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 192,' Hogan Duggan ',' M ',' 12 / 2 / 1998 ',8588472406,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 193,' Cristine Silkstone ',' F ',' 7 / 5 / 1948 ',7450467526,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 194,' Parsifal Hurtic ',' M ',' 7 / 30 / 1947 ',9766545278,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 195,' Miller Station ',' M ',' 12 / 13 / 1921 ',8791940079,184389);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 196,' Terrell Sweetlove ',' M ',' 10 / 28 / 1961 ',4460195798,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 197,' Oriana Ormerod ',' F ',' 9 / 28 / 1908 ',9913671752,' 32 - 865 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 198,' Christy Duckett ',' M ',' 11 / 2 / 1996 ',3025360704,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 199,' Mareah Beaven ',' F ',' 4 / 5 / 1991 ',2201432996,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 200,' Vita Lankester ',' F ',' 5 / 15 / 1900 ',7426996700,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 201,' Mano Flucks ',' M ',' 12 / 29 / 1974 ',4842878258,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 202,' Beatriz Johns ',' F ',' 7 / 8 / 2014 ',0175236496,' 57404 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 203,' Jemmie Schaffel ',' F ',' 2 / 14 / 1995 ',1224844823,' 175 61 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 204,' Ashton Botten ',' M ',' 10 / 5 / 1929 ',1435808371,' 45920 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 205,' Tyrone Brownbridge ',' M ',' 9 / 21 / 1988 ',8687444737,' 4570 - 198 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 206,' Saloma Mumford ',' F ',' 8 / 7 / 2008 ',7703282340,50320);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 207,' Bobbie Fibbings ',' F ',' 2 / 4 / 1901 ',0711465339,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 208,' Ardyth Screeton ',' F ',' 10 / 25 / 1986 ',6578818979,' 183 83 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 209,' Padraic Stennings ',' M ',' 8 / 17 / 1952 ',6082078152,649219);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 210,' Michal Bishell ',' F ',' 3 / 5 / 1902 ',2792440597,93180);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 211,' Leda D 'Onise', 
'F', 
'7/22/1932', 
6269122147, 
''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
212, 'Chalmers Simonetti', 'M', '3/9/1993', 
8389848813, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
213, 'Aldrich Davidsohn', 'M', '1/3/2019', 
3186452910, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
214, 'Rosita Sharpe', 'F', '11/27/1978', 
9514933761, 85754
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
215, 'Adda Rolfe', 'F', '3/11/1966', 
9008974797, '81506 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
216, 'Dorolice Fetherstan', 'F', '3/13/1992', 
5791896883, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
217, 'Avigdor Caws', 'M', '9/22/1968', 
9074544363, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
218, 'Blaire Pashan', 'F', '6/12/1908', 
0449088014, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
219, 'Cully Dubock', 'M', '7/13/1994', 
6985964257, 37800
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
220, 'Garwood Keogh', 'M', '6/8/2008', 
4118775476, '46-100'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
221, 'Ingamar Bockman', 'M', '11/4/1920', 
8985037811, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
222, 'Astrid Di Boldi', 'F', '11/15/1952', 
1146128533, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
223, 'Lucille Pettit', 'F', '12/16/1928', 
3427741443, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
224, 'Tommie Delf', 'M', '2/23/1941', 
3517078360, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
225, 'Diana Skudder', 'F', '3/12/2017', 
4267845646, 10217
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
226, 'Guntar Paulazzi', 'M', '11/9/1920', 
6160074393, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
227, 'Lucky Durkin', 'F', '9/18/1933', 
5295424324, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
228, 'Hillel Richten', 'M', '3/27/2008', 
3777935115, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
229, 'Wendie Yankeev', 'F', '3/21/1979', 
2355154996, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
230, 'Kory Tremathick', 'M', '10/7/1958', 
7426988511, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
231, 'Adi Durante', 'F', '6/5/2002', 
0380946815, '65630-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
232, 'Seward Dansey', 'M', '6/2/1948', 
4491859116, 7213
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
233, 'Gal Dwerryhouse', 'M', '4/1/1975', 
9475422641, 21001
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
234, 'Wynn Greenmon', 'F', '8/21/1913', 
0773061096, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
235, 'Preston Snowball', 'M', '12/20/1940', 
0863333095, 309509
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
236, 'Hailee Oene', 'F', '3/6/1983', 
2667064003, 09220
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
237, 'Deloria Younie', 'F', '10/9/1992', 
9077203591, 652581
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
238, 'Robby Maha', 'M', '5/2/1959', 
7849302796, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
239, 'Nichol Gerraty', 'F', '12/24/1977', 
7538229418, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
240, 'Bart Cuff', 'M', '12/18/2006', 
0358975298, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
241, 'Wendeline Cuff', 'F', '10/18/1944', 
4748873086, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
242, 'Shirlene Cappineer', 'F', '9/2/1940', 
4170485440, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
243, 'Miller Rodson', 'M', '10/2/2007', 
3325578179, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
244, 'Peirce Hellis', 'M', '11/27/1914', 
2166642632, 11509
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
245, 'Clarey Allkins', 'F', '6/26/2006', 
0509877141, '07-202'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
246, 'Sancho Jarritt', 'M', '2/5/1912', 
2760930173, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
247, 'Davidde Bailie', 'M', '5/19/1990', 
7142795158, 96130
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
248, 'Rockwell Boscott', 'M', '2/20/1992', 
5933179973, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
249, 'Ogden Courvert', 'M', '11/15/1968', 
4353088408, 623900
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
250, 'Sherrie Labell', 'F', '4/16/1973', 
9844158044, 2624
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
251, 'Brant Howle', 'M', '8/25/2012', 
0090186508, 47207
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
252, 'Alexis Feyer', 'F', '5/30/1919', 
1781177449, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
253, 'Tadeo Erlam', 'M', '9/10/1949', 
1573697672, '95270-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
254, 'Llywellyn Antat', 'M', '10/23/1924', 
9030292342, '58600-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
255, 'Sianna Salvin', 'F', '1/17/1994', 
5824771316, '60506 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
256, 'Rockey Guppey', 'M', '7/27/1958', 
9453056960, 73119
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
257, 'Mandie MacCallester', 'F', '9/1/1947', 
8211236850, 1109
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
258, 'Brendin Florence', 'M', '9/4/1993', 
6931020358, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
259, 'Virginia Bennett', 'F', '7/21/1996', 
5250162061, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
260, 'Tim Durban', 'M', '6/6/1940', 
3464159256, 663740
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
261, 'Maryann Altoft', 'F', '4/30/1941', 
7270355290, 617110
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
262, 'Paul Grimsditch', 'M', '3/26/1975', 
8191667584, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
263, 'Bernadine Pegden', 'F', '9/19/1949', 
8330847365, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
264, 'Sebastian Connew', 'M', '3/8/1925', 
7542995391, '93737 CEDEX 9'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
265, 'Hanny Geard', 'F', '10/16/1973', 
9963776507, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
266, 'Dianna Blanpein', 'F', '1/7/1967', 
7382989682, '4765-122'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
267, 'Ole Barrick', 'M', '5/11/1990', 
3937997652, 453679
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
268, 'Mariette Flintoff', 'F', '11/16/1984', 
5720884548, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
269, 'Moritz Ney', 'M', '7/24/1932', 
0055403727, 182160
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
270, 'Sherwin Yokel', 'M', '5/18/2015', 
3437934740, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
271, 'Emerson Eccleston', 'M', '5/17/1986', 
4452496997, 056450
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
272, 'Morie Pond', 'M', '1/29/1935', 
1239836856, '35150-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
273, 'Corabel Pickering', 'F', '6/17/1957', 
8542724526, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
274, 'Abbey Mattheissen', 'F', '1/22/1924', 
4321230519, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
275, 'Kendal Leisk', 'M', '8/18/1955', 
3635097144, 6405
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
276, 'Hubie Byer', 'M', '4/5/1995', 
0195203682, 3723
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
277, 'Vallie Dabell', 'F', '12/8/1927', 
9229769266, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
278, 'Filide Bockler', 'F', '4/18/1914', 
5075271111, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
279, 'Darnall Bill', 'M', '8/3/1906', 
0577815423, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
280, 'Nolie Crombleholme', 'F', '10/16/1964', 
8121464390, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
281, 'Gaylor Wasmer', 'M', '8/1/1939', 
4924564826, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
282, 'Webb Giamo', 'M', '12/10/1970', 
0004725263, 13005
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
283, 'Guillemette Burdass', 'F', '5/28/1946', 
7678725280, '89-400'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
284, 'Gallagher Ortiger', 'M', '4/7/1933', 
5946475312, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
285, 'Henryetta Brettoner', 'F', '1/28/2004', 
3326443331, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
286, 'Hyacinth Showt', 'F', '10/5/1978', 
3245573898, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
287, 'Honey Ferry', 'F', '11/1/1931', 
2718230606, '595-0814'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
288, 'Sydelle Skittrell', 'F', '3/4/1991', 
1196133646, '2965-207'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
289, 'Darn Goulbourn', 'M', '2/10/1968', 
6731285471, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
290, 'Broddie Count', 'M', '2/28/1905', 
9703393810, 48324
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
291, 'Tandi Storm', 'F', '1/22/1915', 
2073780318, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
292, 'Raleigh Wallbrook', 'M', '9/16/2016', 
7191649658, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
293, 'Woodrow Babidge', 'M', '1/10/1968', 
6028335231, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
294, 'Menard Kiera', 'M', '4/15/1998', 
6178986807, '944 73'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
295, 'Carolee Perassi', 'F', '3/1/1916', 
3588735321, '97019 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
296, 'Randolf Kinkaid', 'M', '2/13/1976', 
3897520966, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
297, 'Sissy Dockerty', 'F', '1/2/1966', 
5350292978, 2720
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
298, 'Bobby Orman', 'F', '9/29/1999', 
2920263242, '92000-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
299, 'Mackenzie Whitters', 'M', '3/10/1912', 
4604702799, 13210
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
300, 'Bridie Amesbury', 'F', '10/26/1988', 
7968562058, '582 82'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
301, 'Car Wendover', 'M', '9/20/1909', 
0685095584, 347639
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
302, 
'Alfredo O' Hern ',' M ',' 4 / 20 / 1948 ',5112577584,461509);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 303,' Nerty Syne ',' F ',' 8 / 10 / 1944 ',8362294779,680999);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 304,' Michell Bagworth ',' F ',' 1 / 16 / 1953 ',9937543746,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 305,' Dill Guilliland ',' M ',' 10 / 31 / 1991 ',7098481971,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 306,' Rinaldo Nanni ',' M ',' 3 / 15 / 1975 ',7713157026,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 307,' Tiphany Blackhall ',' F ',' 10 / 14 / 1990 ',3215152282,' 899 - 5241 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 308,' Jed Stendell ',' M ',' 7 / 29 / 1910 ',6049704015,' 29327 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 309,' Parnell Ties ',' M ',' 9 / 28 / 1925 ',6671148376,1086);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 310,' Debbie Bougen ',' F ',' 4 / 25 / 1953 ',6244421892,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 311,' Corty Gouth ',' M ',' 9 / 25 / 1950 ',3923468172,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 312,' Audi Radbourn ',' F ',' 11 / 2 / 1990 ',3647267716,' 151 81 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 313,' Kylie Haycraft ',' M ',' 8 / 5 / 1913 ',8565354849,623511);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 314,' Aleksandr Doul ',' M ',' 12 / 13 / 1944 ',3148185129,95140);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 315,' Hendrick Forsey ',' M ',' 11 / 22 / 1902 ',4023724068,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 316,' Ellette Cantwell ',' F ',' 12 / 25 / 1970 ',1333762887,' 820 - 0702 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 317,' Stefan Cornillot ',' M ',' 3 / 24 / 1963 ',2769223879,303580);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 318,' Hugibert Doudny ',' M ',' 2 / 21 / 1981 ',9320131473,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 319,' Talyah Rivalant ',' F ',' 4 / 19 / 1927 ',6808671648,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 320,' Josiah Chevolleau ',' M ',' 5 / 9 / 1975 ',8469432516,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 321,' Tresa Loosely ',' F ',' 12 / 4 / 1945 ',6834009000,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 322,' Nananne Load ',' F ',' 1 / 20 / 1953 ',8616209085,627533);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 323,' Andrey Bingham ',' M ',' 7 / 21 / 1999 ',6118693803,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 324,' Marwin Grolle ',' M ',' 2 / 20 / 1978 ',9695925367,' 171 05 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 325,' Judon Cargo ',' M ',' 3 / 28 / 2007 ',8326006106,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 326,' Faber Gresley ',' M ',' 4 / 4 / 1981 ',4380765571,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 327,' Howard Charville ',' M ',' 6 / 21 / 1987 ',8867290711,6710);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 328,' Eduardo Avrahamov ',' M ',' 3 / 8 / 1930 ',6016348155,21130);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 329,' Marlena Quiddington ',' F ',' 6 / 11 / 1933 ',8253327161,' 88300 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 330,' Aridatha Rule ',' F ',' 11 / 13 / 1972 ',7506232901,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 331,' Edlin Gribbin ',' M ',' 9 / 20 / 1940 ',6857253056,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 332,' Christye Gribbell ',' F ',' 12 / 15 / 1970 ',6357762121,' 4890 - 110 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 333,' Shandee De Ambrosi ',' F ',' 2 / 24 / 2009 ',4039438892,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 334,' Hagen Roon ',' M ',' 11 / 21 / 1921 ',1912735350,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 335,' Colleen Leavey ',' F ',' 2 / 15 / 1951 ',3520947269,' 42 - 460 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 336,' Norina Openshaw ',' F ',' 5 / 17 / 1958 ',1854502417,6545);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 337,' Belva Ordidge ',' F ',' 5 / 14 / 2017 ',8625739571,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 338,' Everard Hertwell ',' M ',' 9 / 24 / 1915 ',5821824710,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 339,' Hermon Fitkin ',' M ',' 6 / 27 / 1966 ',3447717327,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 340,' Quintina Jeafferson ',' F ',' 7 / 19 / 1906 ',1094278157,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 341,' Shoshana Walbrun ',' F ',' 12 / 28 / 2015 ',7199542887,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 342,' Avictor Greveson ',' M ',' 7 / 30 / 2015 ',3154472150,' 98910 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 343,' Nero Giacomini ',' M ',' 5 / 13 / 1996 ',1358858039,7303);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 344,' Alaster Curme ',' M ',' 5 / 23 / 1962 ',2446145205,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 345,' Marlena O 'Fogerty', 
'F', 
'4/2/1931', 
0984892486, 
1412
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
346, 'Alisun Ebhardt', 'F', '11/20/1922', 
3648100025, 'L-7681'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
347, 'Shurwood Syddie', 'M', '11/7/1914', 
6404403706, 7025
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
348, 'Selestina Liepins', 'F', '8/28/2004', 
0162260318, 3240
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
349, 'Abeu Stoodley', 'M', '9/3/2007', 
2898357243, 89714
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
350, 'Craig Roadknight', 'M', '8/1/1981', 
9335796093, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
351, 'Donia Dunster', 'F', '1/5/2013', 
4797879505, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
352, 'Moselle Aguirrezabal', 'F', 
'5/22/1923', 0670970514, '398 06'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
353, 'Chick Kitto', 'M', '7/15/1979', 
8514761684, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
354, 'Gussie Cotherill', 'F', '1/5/2012', 
4992298117, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
355, 'Pearce Starkey', 'M', '1/19/1956', 
1653005076, 690880
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
356, 'Demeter Mateev', 'F', '6/5/1976', 
1701898861, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
357, 'Gail Fiveash', 'M', '1/4/1987', 
2955625914, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
358, 'Sharline Nibley', 'F', '4/8/1911', 
0086195174, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
359, 'Noemi Powlett', 'F', '11/23/1987', 
2004321091, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
360, 'Say Ormes', 'M', '7/6/2004', 
8491308474, '788 15'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
361, 'Kaylee McTrustrie', 'F', '2/9/1935', 
6230128373, 3640
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
362, 'Prudy Waite', 'F', '9/30/1909', 
0775661058, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
363, 'Ronnie McIlraith', 'M', '2/19/1989', 
6857802394, 5004
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
364, 'Barrett Draxford', 'M', '11/28/1913', 
0375543457, 452056
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
365, 'Britni Mayow', 'F', '12/7/1992', 
2560825295, 10309
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
366, 'Georgia Bleiman', 'F', '5/12/1945', 
3483638490, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
367, 'Filberto Forsdicke', 'M', '9/17/1956', 
9092380660, '44830-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
368, 'Trueman Marcone', 'M', '11/5/1914', 
1597148016, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
369, 'Mildred Venturoli', 'F', '12/28/1981', 
7634885177, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
370, 'Wilek Sieb', 'M', '6/26/1968', 
5237100619, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
371, 'Carce Metson', 'M', '9/4/1977', 
6901395817, '8365-059'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
372, 
'Berry O' Monahan ',' F ',' 1 / 6 / 1909 ',0752321013,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 373,' Colline Bland ',' F ',' 4 / 13 / 1938 ',1095497626,91130);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 374,' Willie Byllam ',' F ',' 3 / 11 / 1987 ',1948866897,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 375,' Tammy Coils ',' M ',' 12 / 15 / 2018 ',3605076424,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 376,' Broderick Strapp ',' M ',' 6 / 19 / 2005 ',5369268681,' 827 82 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 377,' Foss Wholesworth ',' M ',' 9 / 22 / 1901 ',5755597472,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 378,' Jephthah Mannering ',' M ',' 9 / 17 / 1998 ',8026567927,3400);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 379,' Karleen Rosencrantz ',' F ',' 5 / 19 / 1939 ',2182906711,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 380,' Cortie Takis ',' M ',' 3 / 3 / 1972 ',6108467398,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 381,' Brittney Comiam ',' F ',' 3 / 18 / 1958 ',7743223701,216464);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 382,' Galvin Seak ',' M ',' 11 / 24 / 1926 ',5428014628,' 748 31 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 383,' Charlie Waleran ',' M ',' 6 / 5 / 1934 ',1130229467,88519);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 384,' Greggory Valentelli ',' M ',' 8 / 26 / 1993 ',9640513024,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 385,' Dana Bushen ',' M ',' 3 / 30 / 1934 ',0713822988,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 386,' Alvin Webb - Bowen ',' M ',' 4 / 8 / 1920 ',2242469800,446849);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 387,' Albertine Sword ',' F ',' 7 / 28 / 1961 ',7324011330,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 388,' Murielle Noton ',' F ',' 7 / 31 / 1930 ',0846132982,301649);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 389,' Mandi Hayworth ',' F ',' 7 / 3 / 1934 ',3048908218,' 35790 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 390,' Reeta McHardy ',' F ',' 11 / 2 / 1909 ',0636354326,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 391,' Reg Murr ',' M ',' 2 / 3 / 1928 ',5018428643,601144);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 392,' Roland Dillaway ',' M ',' 9 / 3 / 2016 ',8192135438,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 393,' Farrell de Vaen ',' M ',' 11 / 6 / 1958 ',1358639167,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 394,' Teddy Tattershaw ',' F ',' 10 / 30 / 2000 ',6166033753,397474);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 395,' Gerry Wedmore.',' F ',' 9 / 3 / 1989 ',0063422123,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 396,' Karie Cuckoo ',' F ',' 1 / 25 / 1991 ',7774550321,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 397,' Melisa Hollingshead ',' F ',' 6 / 6 / 1903 ',0247205737,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 398,' Johnathon Pfeffel ',' M ',' 12 / 24 / 2003 ',3885282992,' 4705 - 653 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 399,' Eartha Mulkerrins ',' F ',' 4 / 22 / 1908 ',3899814436,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 400,' Lissie Filliskirk ',' F ',' 1 / 23 / 1943 ',3063827800,10516);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 401,' Valaria Blest ',' F ',' 6 / 30 / 1959 ',7684000101,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 402,' Nealon Savatier ',' M ',' 10 / 4 / 2011 ',1709020849,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 403,' Benedick Tollemache ',' M ',' 5 / 8 / 1918 ',0543258955,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 404,' Rolfe Suddell ',' M ',' 5 / 31 / 1960 ',9447947786,' 7430 - 015 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 405,' Tabbie Risebarer ',' F ',' 5 / 20 / 1989 ',9351577007,4327);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 406,' Mara Cowen ',' F ',' 10 / 12 / 1993 ',3255978599,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 407,' Mallory Curnucke ',' M ',' 1 / 24 / 2013 ',6547122115,47071);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 408,' Sarena Alsop ',' F ',' 5 / 9 / 2003 ',4945613478,17320);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 409,' Lydon Webb ',' M ',' 10 / 31 / 1970 ',7717991675,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 410,' Jonie Molson ',' F ',' 8 / 26 / 1946 ',8084507362,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 411,' Nero Deetlof ',' M ',' 11 / 28 / 2017 ',5126766392,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 412,' Albert Twining ',' M ',' 8 / 15 / 1929 ',1623992869,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 413,' Barde Ezele ',' M ',' 2 / 9 / 1946 ',5017494871,' 679 02 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 414,' Mathe Scandrite ',' M ',' 6 / 18 / 2013 ',3248745975,12008);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 415,' Augustus Ensley ',' M ',' 4 / 14 / 1978 ',3271977003,2630);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 416,' Lizzy Keith ',' F ',' 8 / 5 / 2010 ',5548375075,6415);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 417,' Alta Willets ',' F ',' 3 / 27 / 1908 ',3599494185,8723);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 418,' Cairistiona Beer ',' F ',' 1 / 27 / 2013 ',0622668374,21880);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 419,' Mignonne Wandrach ',' F ',' 4 / 9 / 1973 ',0034571140,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 420,' Pamelina Hofler ',' F ',' 6 / 18 / 1981 ',5442164003,' 349 - 1148 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 421,' Kattie Gytesham ',' F ',' 9 / 3 / 1977 ',7028697002,' 97308 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 422,' Jada Itzchaki ',' F ',' 7 / 5 / 1980 ',5093156396,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 423,' Victor Simkiss ',' M ',' 8 / 20 / 1995 ',4836746094,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 424,' Irita Simcoe ',' F ',' 7 / 8 / 1904 ',8198406522,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 425,' Perry Cinelli ',' M ',' 2 / 19 / 1906 ',4327161187,446154);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 426,' Cecile Jovis ',' F ',' 12 / 29 / 1935 ',7493975302,' 467 96 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 427,' Benedict Pullan ',' M ',' 2 / 13 / 1925 ',8924356704,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 428,' Malina Gentreau ',' F ',' 11 / 13 / 1916 ',8221122637,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 429,' Fanni Humpatch ',' F ',' 2 / 8 / 1918 ',1647190800,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 430,' Claudell Ramalho ',' M ',' 10 / 29 / 2007 ',2357122641,249080);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 431,' Chance Toffolini ',' M ',' 12 / 19 / 1986 ',0112721079,' 4575 - 069 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 432,' Lilias Janway ',' F ',' 10 / 23 / 1996 ',8285684512,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 433,' Horatia Bradman ',' F ',' 4 / 9 / 1969 ',2597385116,' 442 - 0889 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 434,' Shelden Cornewell ',' M ',' 2 / 4 / 1997 ',8959661074,19139);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 435,' Alyss Alp ',' F ',' 12 / 31 / 1943 ',8076345987,685000);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 436,' Bartram Garm ',' M ',' 2 / 26 / 1922 ',0435433148,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 437,' Stephani Whitehorn ',' F ',' 10 / 4 / 1913 ',3794866940,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 438,' Donal Byk ',' M ',' 2 / 14 / 2005 ',7326021686,8608);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 439,' Tallie Winch ',' F ',' 1 / 9 / 1925 ',6827377040,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 440,' Romona Coley ',' F ',' 4 / 15 / 1929 ',1268213829,' SLM ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 441,' Hercules Milland ',' M ',' 2 / 7 / 1914 ',7153914935,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 442,' Mervin Mulroy ',' M ',' 11 / 5 / 1920 ',6825029541,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 443,' Anne - marie Wannes ',' F ',' 7 / 26 / 2009 ',4833720310,1750);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 444,' Sidonnie Fidilis ',' F ',' 1 / 25 / 1970 ',4961634999,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 445,' Edeline Pennington ',' F ',' 6 / 22 / 2006 ',4957666571,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 446,' Sibelle Pentycross ',' F ',' 5 / 8 / 1944 ',8238200601,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 447,' Mufinella Beverstock ',' F ',' 11 / 5 / 2006 ',0577056670,6034);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 448,' Leisha Oxx ',' F ',' 4 / 19 / 1943 ',5518184336,3503);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 449,' Flossie Chrismas ',' F ',' 11 / 9 / 1936 ',3146420775,20011);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 450,' Cozmo Gilroy ',' M ',' 8 / 11 / 1970 ',4246387770,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 451,' Emlynn Toretta ',' F ',' 5 / 12 / 1929 ',2900799163,3246);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 452,' Jaimie Bullant ',' M ',' 10 / 30 / 2005 ',2861406054,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 453,' Aylmer Shoosmith ',' M ',' 6 / 3 / 1994 ',2825824186,3107);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 454,' Sterling Willavoys ',' M ',' 4 / 9 / 2014 ',9863930318,' 15495 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 455,' Florence Barends ',' F ',' 12 / 24 / 1956 ',2614968951,96980);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 456,' Andonis Larroway ',' M ',' 4 / 8 / 1908 ',9970617168,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 457,' Ericka Jeenes ',' F ',' 2 / 10 / 1922 ',1083951297,58181);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 458,' Marlowe Hollier ',' M ',' 8 / 16 / 2011 ',7167437425,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 459,' Brinna Iczokvitz ',' F ',' 7 / 3 / 1988 ',2206509709,' 592 11 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 460,' Daffi Stirgess ',' F ',' 8 / 30 / 1982 ',6306153659,' 22 - 630 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 461,' Zerk Taree ',' M ',' 1 / 25 / 1936 ',4985708348,' 79404 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 462,' Valentina Trask ',' F ',' 8 / 14 / 1996 ',7002093894,31140);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 463,' Amalle Dannell ',' F ',' 6 / 15 / 1947 ',7297035610,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 464,' Fransisco Morecomb ',' M ',' 9 / 15 / 2007 ',3129164774,96925);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 465,' Marsiella Habbon ',' F ',' 10 / 9 / 1923 ',8443543566,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 466,' Jordan Kinnoch ',' F ',' 3 / 14 / 1948 ',3951826010,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 467,' Carissa Fruin ',' F ',' 9 / 9 / 1902 ',3891903103,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 468,' Dorelle Pietron ',' F ',' 5 / 23 / 1966 ',4950407481,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 469,' Harald Kernan ',' M ',' 5 / 28 / 1947 ',7663808142,853059);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 470,' Jacki Weekland ',' F ',' 3 / 16 / 1995 ',8254519986,2701);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 471,' Ivor Cuttin ',' M ',' 10 / 16 / 2011 ',4547728593,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 472,' Bernie Beardow ',' M ',' 11 / 19 / 1909 ',8846752953,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 473,' Lou Castagnet ',' M ',' 6 / 20 / 1909 ',0456900705,2250);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 474,' Darlleen Ditchfield ',' F ',' 6 / 26 / 1951 ',5670108736,' 2705 - 126 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 475,' Ashlee Spurrier ',' F ',' 10 / 13 / 1928 ',2296113087,' 74 - 503 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 476,' Klaus Nisuis ',' M ',' 9 / 10 / 1907 ',9692452824,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 477,' Halie Cornforth ',' F ',' 8 / 8 / 1966 ',2693287146,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 478,' Florina Knight ',' F ',' 11 / 18 / 1934 ',6302372674,33270);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 479,' Barbara - anne Robic ',' F ',' 1 / 22 / 2018 ',2327967112,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 480,' Horacio Grizard ',' M ',' 1 / 8 / 2016 ',2508019321,35815);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 481,' Freddy Boustead ',' M ',' 1 / 18 / 1996 ',2991705760,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 482,' Clywd Aughtie ',' M ',' 9 / 26 / 1998 ',8181453247,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 483,' Bertrand Melpuss ',' M ',' 8 / 24 / 1959 ',6276304050,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 484,' Lilla Flobert ',' F ',' 10 / 9 / 1914 ',9500558114,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 485,' Terese Ashurst ',' F ',' 1 / 20 / 1945 ',5688750235,249028);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 486,' Luce Deverall ',' F ',' 3 / 17 / 1961 ',5726722973,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 487,' Bird Yakunchikov ',' F ',' 5 / 8 / 1911 ',3384907167,' 968 - 0442 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 488,' Pedro Sussems ',' M ',' 6 / 28 / 1981 ',3939752835,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 489,' Markos Reary ',' M ',' 12 / 17 / 1959 ',2821345224,7005);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 490,' Keeley Leonarde ',' F ',' 7 / 23 / 2003 ',4902188465,71122);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 491,' Rachelle Drinkel ',' F ',' 7 / 9 / 1965 ',6303807852,363001);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 492,' Regen Cleiment ',' M ',' 10 / 22 / 1985 ',4580615905,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 493,' Binni Schaffel ',' F ',' 10 / 8 / 1969 ',7426142612,385123);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 494,' Arne Minger ',' M ',' 1 / 31 / 1995 ',4481492341,' 63 - 740 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 495,' Glenda Seiler ',' F ',' 10 / 23 / 1998 ',2126089061,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 496,' Emmott Soaper ',' M ',' 6 / 12 / 1905 ',1170111947,' 9555 - 197 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 497,' Pace Lewis ',' M ',' 5 / 2 / 1936 ',2055396706,' 15800 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 498,' Emory Lawrence ',' M ',' 1 / 22 / 1931 ',1099758262,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 499,' Dulci Cannam ',' F ',' 5 / 3 / 1927 ',8410329581,2514);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 500,' Elsie Stanning ',' F ',' 11 / 16 / 1987 ',3451252481,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 501,' Essie Wogan ',' F ',' 9 / 13 / 1938 ',1492102601,7119);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 502,' Olympia Philpot ',' F ',' 4 / 3 / 2010 ',7028018873,47214);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 503,' Hollis Staker ',' M ',' 8 / 26 / 1907 ',9544627596,' 62430 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 504,' Cass Beedell ',' M ',' 7 / 29 / 1941 ',7438441504,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 505,' Pierson Allnatt ',' M ',' 10 / 18 / 1975 ',4233503823,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 506,' Brina Cornish ',' F ',' 3 / 27 / 1937 ',7939594206,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 507,' Eadith Castanares ',' F ',' 12 / 21 / 1969 ',5976764371,76330);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 508,' Levon Cello ',' M ',' 4 / 7 / 2012 ',2708207180,' 95 - 045 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 509,' Sonni Garmey ',' F ',' 10 / 13 / 1915 ',2638260428,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 510,' Torrie Adney ',' F ',' 8 / 22 / 1964 ',5078766936,6711);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 511,' Rebe Eddie ',' F ',' 5 / 6 / 2009 ',6138539907,' 55 - 100 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 512,' Livvie Imlach ',' F ',' 2 / 8 / 1969 ',5152584271,' 595 01 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 513,' Wolf Birdsey ',' M ',' 3 / 21 / 1967 ',8217422672,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 514,' Gay Noto ',' M ',' 3 / 19 / 1911 ',2912269016,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 515,' Chris Longley ',' M ',' 8 / 24 / 2015 ',8407566608,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 516,' Crissie Wilse ',' F ',' 8 / 16 / 1912 ',6218353710,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 517,' Claude Comberbach ',' F ',' 7 / 24 / 1975 ',9345330410,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 518,' Theresita Yakubovich ',' F ',' 3 / 12 / 1959 ',3002075590,18190);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 519,' Bent Strain ',' M ',' 10 / 9 / 1924 ',1896885462,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 520,' Avrom Facher ',' M ',' 8 / 2 / 1922 ',5931332758,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 521,' Chaunce MacArdle ',' M ',' 9 / 6 / 1948 ',2769282948,' 729 - 5122 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 522,' Ambros Hollingsbee ',' M ',' 5 / 29 / 1965 ',7919794919,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 523,' Merry Felstead ',' M ',' 11 / 23 / 1913 ',5047227367,' AD600 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 524,' Michail Rome ',' M ',' 6 / 19 / 2005 ',5721666528,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 525,' Solomon Ramsay ',' M ',' 2 / 26 / 1980 ',4666521992,32300);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 526,' Margie Babinski ',' F ',' 1 / 3 / 1977 ',5342211522,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 527,' Tulley MacGruer ',' M ',' 9 / 20 / 1933 ',6938357226,' 54939 CEDEX 9 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 528,' Devlen Tommen ',' M ',' 10 / 2 / 1929 ',1264137591,' 2640 - 394 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 529,' Lorita Ruoss ',' F ',' 3 / 7 / 1967 ',1165160021,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 530,' Chalmers Merdew ',' M ',' 7 / 30 / 1950 ',9336840320,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 531,' Gradey Purrington ',' M ',' 9 / 20 / 2005 ',1601721692,4025);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 532,' Kristian Wychard ',' M ',' 3 / 27 / 2019 ',9880754077,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 533,' Jenelle Legrand ',' F ',' 12 / 22 / 2006 ',0273285947,' 78925 CEDEX 9 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 534,' Oralla Skirlin ',' F ',' 10 / 16 / 2017 ',6756646540,1981);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 535,' Ole Matczak ',' M ',' 11 / 18 / 1974 ',2410708382,1111);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 536,' Clio Gregoire ',' F ',' 11 / 24 / 1977 ',3706607328,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 537,' Garfield Giriardelli ',' M ',' 5 / 6 / 1912 ',3289492508,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 538,' Rosabella Pregal ',' F ',' 8 / 24 / 2001 ',8926078655,6014);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 539,' Asia Harg ',' F ',' 6 / 18 / 1959 ',8994858717,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 540,' Johann Siebart ',' M ',' 11 / 21 / 1990 ',9920432377,60284);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 541,' Gillian Garahan ',' F ',' 11 / 20 / 1958 ',7212423394,46175);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 542,' Maurits Maxfield ',' M ',' 10 / 17 / 1996 ',7577324167,' 2705 - 537 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 543,' Rennie Timbs ',' F ',' 12 / 1 / 1924 ',5063527116,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 544,' Lynnea Hand ',' F ',' 8 / 23 / 1939 ',6515464169,' 37900 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 545,' Skipp Portman ',' M ',' 6 / 10 / 1950 ',6183556955,' 591 34 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 546,' Hetti Lawranson ',' F ',' 6 / 2 / 1979 ',4516542439,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 547,' Margette Yitzhakof ',' F ',' 8 / 23 / 1917 ',4329474646,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 548,' Con Smallman ',' F ',' 9 / 23 / 2004 ',2112828355,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 549,' Bernardine Gierek ',' F ',' 7 / 28 / 1951 ',8226643384,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 550,' Chrysler Sissons ',' F ',' 5 / 24 / 1941 ',2443136418,2431);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 551,' Tabbi Parley ',' F ',' 12 / 11 / 1986 ',2445838886,9205);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 552,' Brant Such ',' M ',' 5 / 23 / 1924 ',5125786241,0539);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 553,' Cherianne Grafton - Herbert ',' F ',' 8 / 17 / 1992 ',6835305207,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 554,' Van Scampion ',' F ',' 11 / 24 / 2009 ',3337099165,456875);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 555,' Hanni Jorczyk ',' F ',' 3 / 6 / 1973 ',2376809223,' A8A ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 556,' Korie Corradini ',' F ',' 9 / 17 / 1968 ',6540389833,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 557,' Marcia Bedenham ',' F ',' 12 / 5 / 1986 ',1667950754,' 43 - 356 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 558,' Andria Rojas ',' F ',' 2 / 3 / 2003 ',9867670388,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 559,' Adelina Crummy ',' F ',' 6 / 6 / 2009 ',9239721797,' 724 63 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 560,' Hermon Hightown ',' M ',' 8 / 31 / 2010 ',7973140670,1060);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 561,' Timothea Ruger ',' F ',' 2 / 1 / 1950 ',7796480806,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 562,' Ruthe Cerman ',' F ',' 2 / 11 / 2009 ',9970646729,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 563,' Bridgette Tyne ',' F ',' 9 / 30 / 1949 ',7201476963,3521);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 564,' Nancie Bullivent ',' F ',' 7 / 2 / 1958 ',7418632916,' 261 27 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 565,' Mason Works ',' M ',' 11 / 15 / 1926 ',6693136796,184433);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 566,' Glynnis Baggs ',' F ',' 6 / 7 / 1970 ',3041695219,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 567,' Dana Paridge ',' F ',' 3 / 10 / 1959 ',4553029847,' 3220 - 523 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 568,' Prentice Huxtable ',' M ',' 2 / 6 / 1912 ',9801297646,83501);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 569,' Julina Chamberlin ',' F ',' 3 / 29 / 1946 ',8033217316,5961);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 570,' Osbourne Lettley ',' M ',' 6 / 19 / 1973 ',6024566778,9610);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 571,' Mead Giovanitti ',' F ',' 6 / 27 / 1943 ',2518378499,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 572,' Josephina Janiak ',' F ',' 1 / 27 / 1958 ',4460607824,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 573,' Marianna Blanque ',' F ',' 3 / 15 / 1999 ',2540876951,4023);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 574,' Clemmie Spuner ',' F ',' 10 / 25 / 1957 ',7134167410,186424);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 575,' Cicely Bouldon ',' F ',' 4 / 14 / 1998 ',0243278071,93650);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 576,' Ara Baudino ',' M ',' 1 / 31 / 1929 ',7794422345,1888);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 577,' Meara Josuweit ',' F ',' 12 / 15 / 1920 ',6710248860,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 578,' Gerard Addy ',' M ',' 11 / 30 / 1956 ',5875045671,' 34186 CEDEX 4 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 579,' Mina Medlin ',' F ',' 3 / 31 / 1989 ',1134110472,4290);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 580,' Velma Burde ',' F ',' 12 / 14 / 1995 ',0067028551,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 581,' Nancie Woolgar ',' F ',' 10 / 7 / 1907 ',7884115697,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 582,' Bennie Maleck ',' M ',' 1 / 16 / 1974 ',9553134009,' 75832 CEDEX 17 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 583,' Maynard Fer ',' M ',' 2 / 5 / 1914 ',2092366629,39010);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 584,' Angie Beet ',' F ',' 4 / 4 / 1987 ',2932224433,85099);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 585,' Homere Ibert ',' M ',' 9 / 18 / 1951 ',9800871519,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 586,' Donelle Umpleby ',' F ',' 2 / 28 / 1909 ',1443880647,2016);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 587,' Barnabe Noblett ',' M ',' 3 / 5 / 1903 ',8144696328,5034);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 588,' Windham Pfeuffer ',' M ',' 1 / 6 / 1945 ',0213166399,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 589,' Griswold Syne ',' M ',' 6 / 12 / 1978 ',3176403526,3220);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 590,' Kalie Verheijden ',' F ',' 6 / 27 / 1978 ',4956690851,90094);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 591,' Regen Padkin ',' M ',' 4 / 25 / 2012 ',1432988239,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 592,' Thorvald Yeoland ',' M ',' 11 / 29 / 1997 ',6411283648,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 593,' Sonnie Osborn ',' F ',' 4 / 11 / 1913 ',1251048900,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 594,' Doti Askew ',' F ',' 4 / 7 / 2014 ',6696963499,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 595,' Hewitt Imorts ',' M ',' 3 / 20 / 1975 ',6472468451,' J9L ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 596,' Mallorie Dummett ',' F ',' 1 / 8 / 1912 ',3640109813,4216);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 597,' Ellie Wrennall ',' F ',' 2 / 18 / 1922 ',9515520967,' 42 - 284 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 598,' Cordelia Champe ',' F ',' 4 / 17 / 2005 ',2525614380,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 599,' Alyse Crocken ',' F ',' 9 / 17 / 2003 ',1507145861,171750);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 600,' Thedric Fike ',' M ',' 9 / 8 / 1995 ',0021396035,663008);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 601,' Franciskus Hornbuckle ',' M ',' 8 / 2 / 1914 ',3250781886,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 602,' Scotti Alcoran ',' M ',' 5 / 5 / 1979 ',8656890050,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 603,' Ferd Carneck ',' M ',' 1 / 7 / 1930 ',2742095187,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 604,' Vidovik Cruise ',' M ',' 9 / 2 / 1912 ',4874213758,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 605,' Ranee Skeemer ',' F ',' 3 / 24 / 1994 ',7387895732,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 606,' Clerissa Scoyne ',' F ',' 2 / 2 / 1946 ',0315655429,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 607,' Hilliard Sapsed ',' M ',' 9 / 7 / 1929 ',4258757535,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 608,' Harland Berger ',' M ',' 10 / 2 / 1945 ',5289299564,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 609,' Margaret Ohrt ',' F ',' 8 / 11 / 1994 ',2493914562,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 610,' Letti Pennick ',' F ',' 3 / 13 / 1928 ',1796051373,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 611,' Addie Kneal ',' M ',' 5 / 30 / 1989 ',5101557978,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 612,' Paolina Dreini ',' F ',' 10 / 4 / 1982 ',0927966646,34160);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 613,' Leia Calles ',' F ',' 11 / 30 / 1984 ',8277287852,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 614,' Hamilton Semered ',' M ',' 7 / 20 / 1997 ',0516854070,340);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 615,' Brigg Gahan ',' M ',' 1 / 8 / 1950 ',8241815573,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 616,' Adrianne Hartly ',' F ',' 9 / 1 / 1938 ',5373070459,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 617,' Hastie Elt ',' M ',' 10 / 26 / 1912 ',2260435416,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 618,' Brien Bows ',' M ',' 8 / 25 / 1903 ',2923736478,665442);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 619,' Morty McIver ',' M ',' 9 / 5 / 1933 ',7679079811,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 620,' Inna Trueman ',' F ',' 2 / 11 / 1928 ',0478664788,860008);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 621,' Emmit Sedman ',' M ',' 5 / 22 / 1982 ',6187984811,4612);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 622,' Hephzibah Hastewell ',' F ',' 5 / 3 / 1927 ',1057348759,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 623,' Karlotte De Laci ',' F ',' 1 / 20 / 1935 ',8262053109,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 624,' Findley Spuner ',' M ',' 9 / 28 / 1931 ',6504642516,3466);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 625,' Onfre Crooke ',' M ',' 9 / 17 / 1927 ',1197519823,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 626,' Jacquelin Copelli ',' F ',' 11 / 22 / 1907 ',3999959908,84605);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 627,' Law Shepherdson ',' M ',' 3 / 11 / 1984 ',6868224435,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 628,' Saidee Ludman ',' F ',' 3 / 8 / 1999 ',7611692429,' 4580 - 245 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 629,' Elston Lendrem ',' M ',' 3 / 12 / 1959 ',8537010952,' 124 76 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 630,' Al Twaite ',' M ',' 8 / 24 / 1970 ',6755618721,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 631,' Kerwinn Whitrod ',' M ',' 7 / 29 / 1973 ',6510099616,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 632,' Dalila Splaven ',' F ',' 11 / 24 / 1924 ',6255081133,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 633,' Payton Laffranconi ',' M ',' 11 / 24 / 1966 ',3192436247,' 45032 CEDEX 1 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 634,' Nata Holby ',' F ',' 2 / 4 / 1904 ',8355885910,' 44 - 295 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 635,' Ricky Gerritzen ',' M ',' 10 / 11 / 1906 ',0761603913,624273);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 636,' Kippie Risen ',' M ',' 11 / 5 / 2002 ',1778917550,4510);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 637,' Sianna Mulvaney ',' F ',' 2 / 2 / 2004 ',1252286260,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 638,' Paulita Glasspoole ',' F ',' 2 / 25 / 1950 ',8275676592,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 639,' Nikolos Ledger ',' M ',' 4 / 23 / 1931 ',0376922044,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 640,' Lamar Goldstraw ',' M ',' 1 / 18 / 1911 ',6194535369,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 641,' Claire Anetts ',' F ',' 3 / 4 / 1982 ',5650939705,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 642,' Humfried Keinrat ',' M ',' 1 / 19 / 1960 ',0450853217,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 643,' Kane Worsley ',' M ',' 9 / 19 / 1919 ',9439922508,665709);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 644,' Quintin Rudolfer ',' M ',' 10 / 31 / 1978 ',3463333449,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 645,' Lora Pordal ',' F ',' 12 / 1 / 2018 ',2472710860,' 62972 CEDEX 9 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 646,' Lyle Betteridge ',' M ',' 5 / 21 / 1932 ',3656045518,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 647,' Kalindi Mugford ',' F ',' 5 / 24 / 1977 ',4956477112,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 648,' Duffy Curtoys ',' M ',' 7 / 13 / 1986 ',6967030361,3776);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 649,' Fae Plaister ',' F ',' 6 / 18 / 1961 ',6351511186,' 85 - 056 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 650,' Louise Bannell ',' F ',' 11 / 6 / 1939 ',5667563908,' 183 15 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 651,' George Breakwell ',' F ',' 11 / 24 / 1997 ',4163270906,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 652,' Dov Gorcke ',' M ',' 2 / 4 / 1918 ',1145148565,111711);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 653,' Hart Wolfinger ',' M ',' 10 / 9 / 1948 ',5073746899,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 654,' Antonetta Olivera ',' F ',' 7 / 21 / 1947 ',3077616904,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 655,' Mead Verdun ',' M ',' 8 / 27 / 1926 ',1358668299,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 656,' Ruperto Launder ',' M ',' 7 / 29 / 1964 ',5614302476,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 657,' Jo - anne Crother ',' F ',' 8 / 3 / 1917 ',4077499771,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 658,' Kimball Gatenby ',' M ',' 8 / 3 / 1932 ',1666646865,36770);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 659,' Kordula Berriball ',' F ',' 2 / 7 / 1935 ',1668903148,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 660,' Ida Connell ',' F ',' 6 / 12 / 1921 ',1640997903,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 661,' Leese Barizeret ',' F ',' 11 / 11 / 1985 ',9048580951,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 662,' Thorpe Craig ',' M ',' 2 / 4 / 1975 ',3922862217,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 663,' Pearla Jensen ',' F ',' 9 / 24 / 1959 ',3457156182,02480);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 664,' Kym Jedryka ',' F ',' 1 / 19 / 1928 ',0483808385,35244);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 665,' Inger Hagley ',' M ',' 11 / 7 / 1994 ',9510773433,' 57230 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 666,' Gerrilee Darnell ',' F ',' 11 / 6 / 1904 ',0847302407,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 667,' Patrick Bettis ',' M ',' 5 / 22 / 1915 ',3426124092,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 668,' Tammie Gascard ',' F ',' 6 / 29 / 1901 ',8023619098,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 669,' Leicester Towll ',' M ',' 6 / 7 / 2000 ',2040944885,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 670,' Vida Uzielli ',' F ',' 6 / 11 / 1988 ',3792209691,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 671,' Lonee Harkin ',' F ',' 5 / 23 / 1948 ',1169822665,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 672,' Anabelle Rollitt ',' F ',' 8 / 11 / 1925 ',5861553874,685518);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 673,' Davey Jephson ',' M ',' 4 / 26 / 2011 ',4626695264,' 39260 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 674,' Godiva Sawforde ',' F ',' 11 / 20 / 1960 ',0075829924,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 675,' Waring Risby ',' M ',' 5 / 20 / 1918 ',9218548913,' 815 92 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 676,' Moses O 'Farrell', 
'M', 
'7/13/1962', 
2903851948, 
'37-114'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
677, 'Leandra Mazella', 'F', '2/18/1974', 
1055637036, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
678, 'Doloritas Moreman', 'F', '9/14/1930', 
2996228383, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
679, 'Rutger Cutford', 'M', '7/8/1917', 
3437551558, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
680, 'Dolf Rothert', 'M', '12/31/1938', 
6716159177, 231008
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
681, 'Kile Pickersail', 'M', '2/22/1912', 
2893493858, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
682, 'Curr Lumly', 'M', '1/11/1900', 
7839564739, 352177
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
683, 'Vic Treven', 'M', '1/3/2002', 
8989586763, 1333
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
684, 'Hymie Wildber', 'M', '12/11/1938', 
7974965185, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
685, 'Dag Benzi', 'M', '11/30/1946', 
5065808864, 703018
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
686, 'May McMackin', 'F', '7/18/1907', 
2286604916, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
687, 'Otho Banat', 'M', '5/4/2017', 
1937795284, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
688, 'Zorina Balwin', 'F', '1/31/1934', 
1338694111, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
689, 'Garner Gawthrope', 'M', '11/8/1984', 
2648886575, 72768
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
690, 'Boy Snasdell', 'M', '1/6/1910', 
0565996061, 3126
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
691, 'Val Neno', 'F', '7/29/1944', 
3823009028, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
692, 'Connie Lorey', 'F', '11/16/1995', 
7707775635, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
693, 'Salomo Beagrie', 'M', '10/3/2010', 
8388832085, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
694, 'Alick Stoodley', 'M', '12/12/1921', 
2840291002, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
695, 'Wilfrid Bruna', 'M', '11/20/1987', 
4822305759, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
696, 'Judon Neagle', 'M', '6/23/1979', 
8882443469, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
697, 'Junina Wilstead', 'F', '12/16/1969', 
7004391698, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
698, 'Hogan Youson', 'M', '12/28/1981', 
5235804635, 22009
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
699, 'Burnard Maddern', 'M', '5/30/1943', 
6755812188, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
700, 'Jameson Chenery', 'M', '9/16/1924', 
2368058486, 33130
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
701, 'Feliza Castellanos', 'F', '9/23/1984', 
6947693543, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
702, 'Waiter Dunridge', 'M', '10/18/1951', 
6143992703, 6407
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
703, 'Freda Moxson', 'F', '1/3/1958', 
3193551015, '2970-182'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
704, 'Chery Low', 'F', '8/23/1924', 
0364709022, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
705, 'Gilemette Witherbed', 'F', '1/7/2002', 
7577337250, '95761 CEDEX 1'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
706, 'Cara Crowcombe', 'F', '5/6/1994', 
2635470561, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
707, 'Lettie Woodard', 'F', '7/6/1916', 
3371042456, 9754
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
708, 'Derry Kaasmann', 'M', '12/17/1926', 
0098035371, 'V92'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
709, 'Douglass Hurche', 'M', '1/14/1908', 
9597260425, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
710, 'Caryl Gheerhaert', 'M', '4/1/1924', 
2758369605, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
711, 'Stearn Tottie', 'M', '4/3/1979', 
9635911505, '471 29'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
712, 'Solly Santoro', 'M', '12/18/2015', 
3086438398, '3025-353'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
713, 'Ado Brunskill', 'M', '12/31/1933', 
8381674484, '29730-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
714, 'Omar Oldcote', 'M', '8/6/1931', 
9933155636, 0919
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
715, 'Daniela Hounihan', 'F', '4/14/1947', 
0804753458, '63-816'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
716, 'Alain Parsell', 'M', '10/10/1915', 
5057021052, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
717, 'Kristal Mordin', 'F', '8/27/1983', 
8877112158, '95760-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
718, 'Danny Skirven', 'M', '11/2/1941', 
4387170735, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
719, 'Humphrey Marton', 'M', '2/10/1983', 
2365365779, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
720, 'Alvy Davion', 'M', '8/28/1906', 
0982250851, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
721, 'Terra Stookes', 'F', '5/4/1931', 
4744492568, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
722, 'Nady Melton', 'F', '7/29/1946', 
3913184732, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
723, 'Liuka Johnsee', 'F', '3/9/1946', 
2804942597, '252 30'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
724, 'Howey Colgan', 'M', '3/29/1913', 
3413755048, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
725, 'Mohammed Knightsbridge', 'M', 
'12/22/1977', 3595093585, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
726, 'Kaylil Cruise', 'F', '4/22/2013', 
0228879469, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
727, 'Astrix Salle', 'F', '7/22/1981', 
5185368543, '92139 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
728, 'Giacobo Finicj', 'M', '2/1/1959', 
6874009192, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
729, 'Mela Dener', 'F', '6/5/1963', 
5791134630, 11506
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
730, 'Aron Fordham', 'M', '4/8/1922', 
0570335965, 692651
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
731, 'Juliana Trimme', 'F', '11/30/1965', 
1601365810, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
732, 'Tessa Oldford', 'F', '3/17/2002', 
8435417158, 18003
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
733, 'Theodore Moses', 'M', '5/20/1951', 
1278566198, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
734, 'Carley Kliner', 'F', '9/5/2009', 
6954490164, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
735, 'Elston Casarino', 'M', '5/26/1911', 
0686510585, 4703
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
736, 'Rory Buckmaster', 'M', '3/19/2014', 
9502255682, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
737, 'Lamond Vasiliev', 'M', '11/12/2004', 
1720881162, '89270-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
738, 'Kittie Loukes', 'F', '11/23/1917', 
6957847810, 7398
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
739, 'Laughton Burlingham', 'M', '11/5/2009', 
3356506706, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
740, 'Maryjane Jedrasik', 'F', '4/4/1961', 
2789899452, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
741, 'Bennett De Zamudio', 'M', '11/21/1949', 
6308103918, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
742, 'Micheal Downgate', 'M', '6/20/1906', 
5891531003, 0915
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
743, 'Claribel Jacobowits', 'F', '9/16/1916', 
8897090699, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
744, 'Federico McCabe', 'M', '6/11/2000', 
2669066577, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
745, 'Kele Guerrazzi', 'M', '3/18/2007', 
8798035169, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
746, 'Pincas Tukesby', 'M', '11/7/1910', 
1894479106, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
747, 'Jamal Gellett', 'M', '1/30/1937', 
7211527617, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
748, 'Dalt Venables', 'M', '1/15/1974', 
8549240974, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
749, 'Zonnya Coots', 'F', '1/20/1946', 
7225887882, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
750, 'Aloin Hully', 'M', '10/23/1942', 
7784528906, 16005
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
751, 'Sammie Aylett', 'M', '6/16/1996', 
4866460245, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
752, 'Frazer Corp', 'M', '3/11/1942', 
2827144131, '999-0606'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
753, 'Lissa Lambersen', 'F', '8/29/1901', 
3989920316, 171270
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
754, 'Pattie Walduck', 'F', '1/9/1971', 
4453433689, '321-1436'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
755, 'Jerald Crummie', 'M', '9/21/1985', 
7091672011, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
756, 'Earlie Beston', 'M', '6/22/1967', 
1315884615, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
757, 'Kennith Crecy', 'M', '4/11/1930', 
2643420004, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
758, 'Gisela Phare', 'F', '2/16/1955', 
8724493554, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
759, 'Kaia Pinkerton', 'F', '2/13/1993', 
4400577589, '34-103'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
760, 'Jere Juorio', 'F', '6/6/2016', 
9802434388, '367-0251'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
761, 'Aggy Dilleston', 'F', '3/28/2016', 
3540982817, '77645-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
762, 'Bekki Espinoy', 'F', '5/2/1948', 
5789965792, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
763, 'Luis Sharland', 'M', '8/18/1942', 
4029364632, '37750-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
764, 'Loy Winmill', 'M', '1/9/1909', 
4541343010, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
765, 'Susy Avesque', 'F', '12/16/1999', 
7690443044, 10131
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
766, 'Florry Sarten', 'F', '6/21/1929', 
9444302083, 5914
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
767, 'Adler Surmon', 'M', '8/6/1919', 
1341608921, 5260
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
768, 'Sheila Etchingham', 'F', '2/19/1928', 
5326444968, 361326
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
769, 'Eldridge Langelaan', 'M', '8/24/1935', 
9299773246, 9321
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
770, 'Phaidra Crone', 'F', '8/29/1992', 
3115709595, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
771, 'Jeno Jarratt', 'M', '9/19/1962', 
7106771570, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
772, 'Marlo Hoonahan', 'M', '5/25/1994', 
3556554763, '59380-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
773, 'Tammara Savage', 'F', '3/24/2006', 
8482736442, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
774, 'Rosalyn Tommei', 'F', '3/16/1901', 
0968387616, '761 51'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
775, 'Ellery Kunneke', 'M', '2/9/1947', 
0898532043, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
776, 'Roda Phillcox', 'F', '3/29/1999', 
5818644286, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
777, 'Holmes Copins', 'M', '12/13/1978', 
7869249734, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
778, 'Sashenka Askem', 'F', '10/17/2014', 
1819295788, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
779, 'Daron Langan', 'F', '11/4/1953', 
5253290486, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
780, 'Findlay Fildes', 'M', '3/18/1916', 
2373053055, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
781, 'Arlie Lodevick', 'F', '9/8/1967', 
1184613362, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
782, 'Leodora Fido', 'F', '12/24/1931', 
9124922773, 636785
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
783, 'Rhianna Stebbings', 'F', '10/23/1998', 
7696489755, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
784, 'Jerrie Pannett', 'F', '5/11/1921', 
1705019064, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
785, 'Kendrick Cato', 'M', '1/8/2009', 
5807761871, '94224 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
786, 'Shaun Stealfox', 'F', '7/1/1944', 
8950242648, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
787, 'Valentine Lapish', 'M', '1/7/1903', 
1227819528, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
788, 'Hervey Mecchi', 'M', '10/24/1965', 
8053068375, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
789, 'Selby Baldoni', 'M', '7/17/1986', 
6331998373, '263 01'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
790, 'Ker Fierro', 'M', '2/14/1906', 
6483887957, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
791, 'Raimund Mintram', 'M', '2/21/1947', 
4205653395, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
792, 'Marilin Houselee', 'F', '8/24/1967', 
6169322926, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
793, 'Cord Postance', 'M', '8/21/1972', 
2637358394, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
794, 'Gillian Byne', 'F', '5/6/1950', 
8296569612, '88750-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
795, 'Liesa Bickerton', 'F', '2/29/1956', 
4614394256, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
796, 'Marve Huett', 'M', '8/11/1928', 
6103662508, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
797, 'Tatiania Bonnier', 'F', '3/16/1982', 
3982805058, 353810
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
798, 'Sadella Eickhoff', 'F', '3/9/1926', 
4269333502, '77794 CEDEX'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
799, 'Emlynne Bradley', 'F', '4/7/1921', 
7459857475, '572 60'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
800, 'Jolie Thwaite', 'F', '9/15/1950', 
2030853151, 76130
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
801, 'Aimil Gooderham', 'F', '2/16/1992', 
3353101454, 44315
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
802, 'Kirk Gatiss', 'M', '1/7/1970', 
6753806148, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
803, 'Alphonse Curtiss', 'M', '11/22/1941', 
1453294597, 54300
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
804, 'Umeko Urian', 'F', '9/19/1927', 
3491117607, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
805, 'Jervis Wetter', 'M', '4/27/2010', 
7875511267, '3800-745'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
806, 'Auroora McGinn', 'F', '5/8/2006', 
6728121889, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
807, 'Judah Worvill', 'M', '7/30/1920', 
2066754536, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
808, 'Lesly Quartermain', 'F', '7/22/1943', 
9942815325, '90-510'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
809, 'Maxie Fransman', 'M', '3/19/1914', 
5834267866, 33673
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
810, 'Hastie Hartzenberg', 'M', '4/15/1963', 
3388719543, 5214
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
811, 'Gannon Drewell', 'M', '10/8/1925', 
6244340671, 192289
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
812, 'Kori Jantzen', 'F', '11/15/1989', 
2521162337, 6525
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
813, 'Devinne Middlebrook', 'F', '7/3/1990', 
5172684034, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
814, 'Reba Poulsom', 'F', '7/25/1977', 
4283382612, '19-411'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
815, 'Artur Alfonso', 'M', '4/16/1970', 
3143404035, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
816, 'Casie Wellan', 'F', '3/27/2002', 
0167827294, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
817, 'Liva Episcopio', 'F', '9/30/1941', 
9556469923, 302525
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
818, 'Amery Mandal', 'M', '5/1/1995', 
7560896995, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
819, 'Anallese Pagram', 'F', '12/10/1939', 
1927856132, '2140-605'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
820, 'Bordy Bonus', 'M', '9/2/2006', 
6686264636, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
821, 
'Northrop O' Donohue ',' M ',' 7 / 30 / 1980 ',6464687557,' 981 - 0503 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 822,' Leelah Meenehan ',' F ',' 1 / 20 / 2015 ',7314950393,403538);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 823,' Hale Spillman ',' M ',' 6 / 4 / 1918 ',7420457204,' 78000 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 824,' Em Jedraszczyk ',' F ',' 7 / 18 / 1964 ',6339194796,' 939 - 1733 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 825,' Frederico McGhie ',' M ',' 9 / 22 / 1979 ',7398407564,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 826,' Ynez Forcer ',' F ',' 1 / 20 / 1949 ',1833930703,' 38009 CEDEX 1 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 827,' Sanderson de Courcy ',' M ',' 12 / 18 / 2016 ',8849333668,5212);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 828,' Jasmin McMichell ',' F ',' 9 / 2 / 1939 ',8064441250,631008);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 829,' Cirstoforo Brumbie ',' M ',' 11 / 21 / 1978 ',1373708042,3282);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 830,' Stephie Benza ',' F ',' 4 / 5 / 1962 ',5124072946,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 831,' Celine Kincaid ',' F ',' 6 / 23 / 2012 ',6735899466,1079);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 832,' Samantha Alman ',' F ',' 7 / 8 / 1912 ',3983402720,416507);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 833,' Patin Hinkins ',' M ',' 9 / 23 / 1943 ',5989980272,606950);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 834,' Skipper De la Harpe ',' M ',' 5 / 16 / 1999 ',7204818865,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 835,' Christophe Sugarman ',' M ',' 6 / 6 / 1984 ',2126917207,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 836,' Suzie Haslin ',' F ',' 8 / 10 / 2017 ',7932911575,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 837,' Dick Lambrick ',' M ',' 7 / 13 / 1941 ',6901631286,186670);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 838,' Farris Van Halen ',' M ',' 12 / 13 / 1942 ',4710839751,' 4620 - 261 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 839,' Marley Spinella ',' F ',' 8 / 16 / 1928 ',7279126782,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 840,' Eziechiele Gamlyn ',' M ',' 12 / 2 / 1913 ',0419172025,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 841,' Rustie Tackle ',' M ',' 1 / 17 / 1999 ',8494349570,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 842,' Welsh Shorey ',' M ',' 1 / 11 / 1905 ',4352639095,' 735 41 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 843,' Allissa de Mendoza ',' F ',' 3 / 14 / 1919 ',3673018299,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 844,' Mervin Dockerty ',' M ',' 2 / 27 / 1978 ',3888561922,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 845,' Tobiah Maker ',' M ',' 7 / 31 / 1940 ',8687469373,' 94593 CEDEX 2 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 846,' Sarena Lewsam ',' F ',' 7 / 15 / 1921 ',6148619318,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 847,' Cordelie Weare ',' F ',' 11 / 13 / 2002 ',6954126179,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 848,' Edyth Castelijn ',' F ',' 8 / 9 / 1980 ',8775819988,' SN1 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 849,' Jojo Thorn ',' F ',' 3 / 13 / 1965 ',7945313574,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 850,' Jerrie Borer ',' M ',' 10 / 24 / 2014 ',6029827774,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 851,' Kin Tuerena ',' M ',' 12 / 9 / 1934 ',8004575498,23242);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 852,' Elinor Mularkey ',' F ',' 3 / 8 / 1969 ',0653220103,346516);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 853,' Papagena Rive ',' F ',' 6 / 30 / 1911 ',5050078458,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 854,' Lotti Burrass ',' F ',' 7 / 1 / 1990 ',8156458389,2814);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 855,' Sheree Gieves ',' F ',' 6 / 10 / 1974 ',2013502206,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 856,' Drud Innwood ',' M ',' 9 / 12 / 1966 ',6034212731,5103);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 857,' Richart Maffezzoli ',' M ',' 4 / 12 / 1915 ',3525365195,' 19780 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 858,' Ronda Gennings ',' F ',' 10 / 4 / 1956 ',3499094754,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 859,' Emilee Possell ',' F ',' 5 / 12 / 1945 ',6431858727,162572);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 860,' Sheppard McKeaveney ',' M ',' 8 / 2 / 1949 ',0693161973,1715);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 861,' Alethea Cluely ',' F ',' 9 / 8 / 1957 ',3444372353,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 862,' Ricky Grovier ',' F ',' 11 / 17 / 1944 ',4090434599,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 863,' Brody St Ledger ',' M ',' 8 / 2 / 1909 ',2222371260,67130);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 864,' Burtie Notti ',' M ',' 12 / 26 / 1920 ',6070631323,' 289 14 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 865,' Shirleen Nyland ',' F ',' 1 / 22 / 1950 ',6811454113,' 44570 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 866,' Marja Jeakins ',' F ',' 10 / 6 / 1961 ',7476577256,2614);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 867,' Reggy Fatscher ',' M ',' 1 / 22 / 1981 ',6361371271,70690);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 868,' Arabella Scarsbrooke ',' F ',' 3 / 28 / 1933 ',4940097722,' 956 - 0861 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 869,' Stavro Carnell ',' M ',' 9 / 29 / 1926 ',2965199888,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 870,' Corey O 'Shields', 
'F', 
'6/21/1930', 
9480944065, 
46160
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
871, 
'Sherry O' Dwyer ',' F ',' 8 / 14 / 1981 ',7395235320,78151);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 872,' Dorise Eusden ',' F ',' 12 / 16 / 1984 ',4977191773,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 873,' Zeke Mulqueen ',' M ',' 11 / 7 / 1934 ',3862028631,3832);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 874,' Dari Putterill ',' F ',' 4 / 30 / 1940 ',8630172843,544529);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 875,' Josey Bramstom ',' F ',' 2 / 5 / 2007 ',4754522605,11007);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 876,' Juieta Hemphill ',' F ',' 4 / 17 / 1971 ',0669961272,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 877,' Dov Pycock ',' M ',' 8 / 30 / 1963 ',0712684662,' 840 - 2105 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 878,' Blake Nazaret ',' M ',' 4 / 2 / 1912 ',2131283962,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 879,' Dorene Tranmer ',' F ',' 4 / 10 / 1944 ',6022359252,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 880,' Llewellyn Leathley ',' M ',' 12 / 11 / 1908 ',4800020905,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 881,' Ned Sibbe ',' M ',' 9 / 15 / 1957 ',7746341691,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 882,' Ibbie Oswell ',' F ',' 2 / 4 / 1914 ',5269455196,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 883,' Rica Crenshaw ',' F ',' 1 / 29 / 1953 ',5440792058,' 953 - 0062 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 884,' Peggy Rushford ',' F ',' 2 / 14 / 1972 ',1778609953,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 885,' Zed Salan ',' M ',' 8 / 23 / 1972 ',4314861355,' 92061 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 886,' Batsheva Sweatland ',' F ',' 3 / 17 / 1955 ',7779987620,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 887,' Emmy Asquez ',' M ',' 10 / 11 / 1963 ',1134802048,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 888,' Trescha Ream ',' F ',' 10 / 8 / 1991 ',9068750577,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 889,' Erminia Boxhill ',' F ',' 3 / 30 / 1973 ',3092997697,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 890,' Florette Gulc ',' F ',' 4 / 10 / 2000 ',0539289051,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 891,' Jarrid Bloxsum ',' M ',' 8 / 28 / 1987 ',7746562043,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 892,' Leigh Verbeke ',' M ',' 7 / 17 / 1945 ',0473428768,443049);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 893,' Theobald Toke ',' M ',' 3 / 18 / 1902 ',6310495054,' 73750 - 000 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 894,' Deana Zorzin ',' F ',' 8 / 12 / 1914 ',0666770050,2900);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 895,' Harald Cheeseman ',' M ',' 3 / 5 / 1910 ',0235354066,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 896,' Gabey Dallewater ',' F ',' 2 / 2 / 1953 ',1971158860,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 897,' Chloe Helsdon ',' F ',' 5 / 6 / 2002 ',1295133601,2254);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 898,' Kathi Yate ',' F ',' 6 / 29 / 1935 ',2712519620,91103);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 899,' Tim Delgadillo ',' M ',' 3 / 5 / 1933 ',7547387470,' 94434 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 900,' Reuven Pattingson ',' M ',' 4 / 28 / 1977 ',0692006575,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 901,' Sergeant Nolli ',' M ',' 5 / 30 / 1955 ',2725270928,' 721 06 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 902,' Quinn Karpf ',' M ',' 6 / 27 / 2004 ',3430045258,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 903,' Abbie Baise ',' M ',' 9 / 5 / 1916 ',8255213260,' 69939 CEDEX 20 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 904,' Robinia Kiraly ',' F ',' 7 / 25 / 1994 ',8767118763,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 905,' Dugald Wooler ',' M ',' 1 / 6 / 1938 ',3146034212,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 906,' Evvie Eytel ',' F ',' 1 / 23 / 1990 ',0049948334,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 907,' Christophe Yakushkev ',' M ',' 10 / 17 / 1978 ',0708218008,2436);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 908,' Dena Raggitt ',' F ',' 5 / 10 / 1961 ',1385152842,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 909,' Westley Brightling ',' M ',' 3 / 29 / 1900 ',5042015833,' 95 - 036 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 910,' Burl Macallam ',' M ',' 9 / 10 / 2007 ',2415122696,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 911,' Diandra Yepiskov ',' F ',' 10 / 8 / 1966 ',4472764377,' 747 30 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 912,' Devy Shawell ',' M ',' 4 / 3 / 1932 ',5519892229,' 351 97 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 913,' Rycca Biggar ',' F ',' 11 / 27 / 1950 ',8931968701,80615);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 914,' Arabella Twitchett ',' F ',' 1 / 13 / 2009 ',4972304669,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 915,' Deb Southouse ',' F ',' 1 / 4 / 1942 ',6982748227,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 916,' Beulah Yearby ',' F ',' 4 / 3 / 1977 ',7999730416,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 917,' Ruttger Brandreth ',' M ',' 2 / 21 / 1914 ',5481970864,' 518 01 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 918,' Darleen Stoyle ',' F ',' 11 / 12 / 1960 ',1803014598,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 919,' Mahmud Vasilchikov ',' M ',' 7 / 13 / 1992 ',7006812976,' 38 - 315 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 920,' Blinnie Sheehan ',' F ',' 2 / 20 / 1917 ',2170168923,87028);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 921,' Lionel McKomb ',' M ',' 4 / 1 / 1982 ',1149471034,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 922,' Kate Popelay ',' F ',' 11 / 6 / 2001 ',5929685088,11109);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 923,' Nertie Gulberg ',' F ',' 10 / 14 / 1971 ',7387536619,649743);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 924,' Celia McCobb ',' F ',' 2 / 14 / 1910 ',1607663422,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 925,' Tan Lachaize ',' M ',' 11 / 22 / 1965 ',3956576373,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 926,' Darryl Pennazzi ',' M ',' 1 / 31 / 1950 ',9619776542,' 99 - 423 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 927,' Mylo Hovert ',' M ',' 10 / 31 / 1981 ',9189223292,4105);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 928,' Frederigo Craine ',' M ',' 8 / 7 / 2006 ',1647426944,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 929,' Glynn Wearing ',' M ',' 5 / 19 / 1970 ',1781632456,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 930,' Pierre Tredget ',' M ',' 2 / 21 / 1999 ',7640681960,8304);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 931,' Cecily Jakobsson ',' F ',' 11 / 8 / 1900 ',7237620746,1041);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 932,' Chrisse McAlester ',' M ',' 11 / 6 / 1938 ',8056234233,3064);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 933,' Tommi Poundsford ',' F ',' 11 / 21 / 1986 ',8976643216,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 934,' Carolann Gowling ',' F ',' 4 / 4 / 1948 ',5567431406,40160);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 935,' Marisa Linfitt ',' F ',' 9 / 7 / 1982 ',6581880256,51281);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 936,' Emmi Esmonde ',' F ',' 9 / 9 / 1921 ',9420951812,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 937,' Susette Bahlmann ',' F ',' 5 / 14 / 1987 ',3412337455,79960);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 938,' Dorey Caulton ',' F ',' 11 / 10 / 1903 ',6295843247,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 939,' Meade Arndell ',' F ',' 6 / 6 / 1954 ',9281015811,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 940,' Fritz Wigg ',' M ',' 9 / 25 / 1926 ',0427333660,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 941,' Marina Dugald ',' F ',' 11 / 14 / 1997 ',3982155452,' 471 14 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 942,' Dunstan Ughi ',' M ',' 1 / 9 / 2009 ',2399658817,' 631 85 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 943,' Tomasine Reolfi ',' F ',' 10 / 16 / 1982 ',4255096171,84280);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 944,' Hakim Ledgeway ',' M ',' 8 / 18 / 2003 ',5042349847,' 4810 - 578 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 945,' Steven Bailes ',' M ',' 2 / 2 / 1935 ',3804548857,130537);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 946,' Theadora Mebes ',' F ',' 3 / 3 / 1934 ',7853685963,' 9630 - 189 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 947,' Meryl Americi ',' M ',' 3 / 11 / 1910 ',3167045388,' 798 47 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 948,' Dena Travers ',' F ',' 8 / 15 / 1986 ',2956595601,' 73216 CEDEX ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 949,' Trent Bedlington ',' M ',' 3 / 31 / 1931 ',2542624399,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 950,' Ina Boatwright ',' F ',' 7 / 27 / 1936 ',9366615082,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 951,' Leopold Danks ',' M ',' 12 / 15 / 1928 ',5935787997,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 952,' Filmer Sherrell ',' M ',' 4 / 5 / 1978 ',5047626105,143142);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 953,' Martie Sterrick ',' F ',' 7 / 1 / 1936 ',1555192033,' 47 - 180 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 954,' Codie Vedstra ',' F ',' 11 / 21 / 1990 ',1529678560,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 955,' Barry McCobb ',' F ',' 5 / 17 / 1927 ',7053174174,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 956,' Dolph Paulitschke ',' M ',' 8 / 31 / 1965 ',6830804442,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 957,' Ahmad McTurley ',' M ',' 8 / 10 / 1975 ',7308905772,1699);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 958,' Ely Sarll ',' M ',' 3 / 27 / 2015 ',4521144837,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 959,' Stanleigh Richards ',' M ',' 4 / 29 / 1954 ',5591509177,4430);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 960,' Tobye Lindup ',' F ',' 7 / 17 / 1985 ',2453990810,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 961,' Rock O 'Neal', 
'M', 
'3/14/1926', 
0227466527, 
''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
962, 'Eugene McBoyle', 'M', '12/14/1941', 
0299252817, '62320-000'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
963, 'Dyanna Marler', 'F', '1/22/2001', 
7047325182, '79031 CEDEX 9'
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
964, 'Gaile Magovern', 'M', '9/24/1967', 
9518287198, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
965, 'Lorant Youhill', 'M', '7/15/1923', 
5840464910, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
966, 'Andrus Limon', 'M', '4/9/1988', 
7889151764, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
967, 'Filippo McClune', 'M', '7/17/1902', 
4497908100, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
968, 'Mada Treadaway', 'F', '5/31/1938', 
5379521711, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
969, 'Georgianne Brant', 'F', '1/11/1992', 
1334557802, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
970, 'Faydra Milch', 'F', '1/13/2008', 
6129169302, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
971, 'Min Fant', 'F', '1/5/1966', 8675655355, 
''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
972, 'Mavis Senchenko', 'F', '1/7/1988', 
2235856152, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
973, 'Hermann Mechi', 'M', '2/12/1989', 
4389763709, 4336
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
974, 'Caroljean McGaugan', 'F', '2/27/1927', 
4480304142, 5965
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
975, 'Gabriella Bushen', 'F', '2/24/1954', 
1164568264, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
976, 'Shelby Turtle', 'M', '7/28/1947', 
0340885017, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
977, 'Moselle Scripture', 'F', '12/1/2007', 
1165461463, ''
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
978, 'Swen Woodman', 'M', '4/30/1974', 
1322898472, 32628
);
INSERT INTO patient(
p_ssn, p_name, gender, b_date, contact_no, 
pin_code
) 
VALUES 
(
979, 
'Natty O' Criane ',' M ',' 3 / 19 / 1962 ',6869798532,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 980,' Livvy Baffin ',' F ',' 4 / 10 / 1902 ',1276210841,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 981,' Lorilee Tucsell ',' F ',' 4 / 22 / 1956 ',5780311331,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 982,' Ali Chastelain ',' M ',' 2 / 4 / 1972 ',7385746411,' 472 01 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 983,' Eda Luckham ',' F ',' 10 / 14 / 1953 ',2481543289,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 984,' Claude Caughey ',' F ',' 9 / 27 / 1963 ',4477759711,347686);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 985,' Ephrem Biggs ',' M ',' 7 / 18 / 1957 ',3127846487,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 986,' Abelard Banbrook ',' M ',' 8 / 4 / 1929 ',8566023293,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 987,' Jethro Kellaway ',' M ',' 12 / 4 / 1921 ',0725630132,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 988,' Melissa Buller ',' F ',' 5 / 2 / 1910 ',6331276084,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 989,' Amalee Farish ',' F ',' 4 / 26 / 1980 ',9811906726,64187);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 990,' Lanie Barday ',' F ',' 11 / 5 / 1952 ',5269746662,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 991,' Stinky Mays ',' M ',' 5 / 19 / 2016 ',6589690073,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 992,' Arron Kohrsen ',' M ',' 3 / 5 / 1920 ',6075032304,232517);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 993,' Krystalle Greason ',' F ',' 5 / 26 / 1995 ',0624323439,1718);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 994,' Wendall Robiou ',' M ',' 8 / 16 / 1932 ',8634663949,80100);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 995,' Washington Parlott ',' M ',' 11 / 17 / 1985 ',3972734174,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 996,' Mavis Ballendine ',' F ',' 4 / 24 / 1971 ',5147898549,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 997,' Keane Suart ',' M ',' 3 / 10 / 1925 ',3697155253,5212);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 998,' Aliza Bullus ',' F ',' 11 / 7 / 1956 ',6488792679,8509);INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 999,' Torr Phizakarley ',' M ',' 9 / 2 / 1901 ',7549073201,' 415 22 ');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( 1000,' Arlan Glancey ',' M ',' 5 / 25 / 1914 ',0127319506,'');INSERT INTO patient(p_ssn,p_name,gender,b_date,contact_no,pin_code) VALUES( '');
